"""
Package for curupira.
"""
